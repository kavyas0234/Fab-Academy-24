import { initializeApp } from "firebase/app";
import { getDatabase, ref } from "firebase/database";
import { Chart } from 'chart.js/auto'

export function getDatabaseRef() {
  const firebaseConfig = {
    apiKey: "AIzaSyCW5AAJHVtJeqLJT2cqpttGpUJFAqIX9Qk",
    authDomain: "kavyas-breathing-library.firebaseapp.com",
    databaseURL: "https://kavyas-breathing-library-default-rtdb.firebaseio.com",
    projectId: "kavyas-breathing-library",
    storageBucket: "kavyas-breathing-library.appspot.com",
    messagingSenderId: "1027539622160",
    appId: "1:1027539622160:web:86b790ef58de85591c2d95",
    measurementId: "G-5TBJ970KLK"
  };

  const app = initializeApp(firebaseConfig);
  const database = getDatabase(app);
  return ref(database)
}
export function initializeChart(canvas, timestamplabels, label, dataset, borderColor, backgroundColor) {
  const existingChart = Chart.getChart(canvas);
  let data;
  let scale;
  if (existingChart) {
      existingChart.destroy();
  }

  if (label === 'co2') {
    data = [
      {
        label: 'co2',
        data: dataset.co2,
        tension: 0.4,
        borderColor: '#37383F',
        backgroundColor: '#4B4B52',
        pointStyle: 'cross',
        // fill: true
      },
    ]
    scale = {}
    
  } else {
    data = [
      {
        label: 'Temperature',
        data: dataset.temperature,
        tension: 0.4,
        borderColor: '#FB3727',
        backgroundColor: '#E9786F',
        pointStyle: 'cross',
        // fill: true
      },
      {
        label: 'Humidity',
        data: dataset.humidity,
        tension: 0.4,
        borderColor: '#2499F4',
        backgroundColor: '#60B5F8',
        pointStyle: 'cross',
        // fill: true
      },
    ]

    scale = {
      x: {

      },
      y: {
        min: 0,
        max: 100
      }
    }
  }

  const chartData = {
      type: 'line',
      data: {
        labels: timestamplabels,
        datasets: data,
      },
      options: {
          responsive: true,
          interaction : {
              mode: 'index',
              intersect: false,
          },
          scales: scale
      },
  }
  new Chart(canvas, chartData);
}

