import './style.css'
import { getDatabaseRef, initializeChart } from './functions'
import { onValue, update } from 'firebase/database'

$(document).ready(() => {
  const co2 = document.getElementById('co2');
  const temp = document.getElementById('temp');
  const humidity = document.getElementById('humidity');
  const timeStamps = document.querySelectorAll('.timeStamp');
  const modeValue = document.getElementById('modeValue');
  const ledSwitch = document.getElementById('switch');
  const changeMode = document.getElementById('changeMode');
  const airatorSwitch = document.getElementById('airatorSwitch');
  const canvas = document.getElementById('chart');
  const co2Canvas = document.getElementById('co2Chart')


  const databaseRef = getDatabaseRef()
  onValue(databaseRef, (snapshot) => {
    const data = snapshot.val()
    // console.log(data)

    // ------------------------------ Current Readings -------------------------------
    co2.textContent = data.Live.data.co2;
    temp.textContent = data.Live.data.temprature;
    humidity.textContent = data.Live.data.humidity;

    const options = { 
      timeZone: 'Asia/Kolkata', 
      hour12: true, 
      hour: 'numeric', 
      minute: '2-digit',
      // year: 'numeric',
      month: 'short',
      day: 'numeric'
    };
    const timeStamp =data.Live.data.timestamp * 1000
    const currentTimeString = new Date(timeStamp).toLocaleString('en-US', options);
    timeStamps.forEach( timeStamp => timeStamp.textContent = currentTimeString )

    // ----------------------- Graph with the recent readings -------------------------
    const history = data.Live.history;
    const timestampArray = Object.keys(history);
    const last10stamps = timestampArray.slice(-10);
    const time1 = new Date(last10stamps[0] * 1000).toLocaleString('en-US', {timeZone: 'Asia/Kolkata',  month: 'short', day: 'numeric'})
    const time2 = new Date(last10stamps[last10stamps.length - 1] * 1000).toLocaleString('en-US', {timeZone: 'Asia/Kolkata',  month: 'short', day: 'numeric'})

    const timeStampLabels = [];
    const co2Array = [];
    const tempArray = [];
    const humidityArray = [];

    last10stamps.forEach(timestamp => {
      let entry = history[timestamp];
      co2Array.push(entry.co2);
      tempArray.push(entry.temprature);
      humidityArray.push(entry.humidity);
      const timestring = new Date(timestamp * 1000).toLocaleString('en-US', options);
      timeStampLabels.push(timestring);
    })

    const dataset = {
      co2: co2Array,
      temperature: tempArray,
      humidity: humidityArray
    }
    initializeChart(canvas, timeStampLabels, 'other', dataset, '#00ff003d', '#00ff003d');
    initializeChart(co2Canvas, timeStampLabels, 'co2', dataset, '#00ff003d', '#00ff003d');

    // ----------------------- LED Switch Control and Status ---------------------------
    ledSwitch.checked = data.Config.control.mode !== 0;

    if (data.Config.control.mode === 1) {
      modeValue.innerHTML = 'Grow Light <i class="fa-solid fa-leaf"></i>';
      modeValue.dataset.mode = 1;
    } else if (data.Config.control.mode === 2) {
      modeValue.innerHTML = 'Wavy White <i class="ml-2 fa-solid fa-water"></i>';
      modeValue.dataset.mode = 2;
    } else if (data.Config.control.mode === 3) {
      modeValue.innerHTML = 'Glow White <i class="fa-solid fa-rainbow"></i>';
      modeValue.dataset.mode = 3;
    } else if (data.Config.control.mode === 4) {
      modeValue.innerHTML = 'Glow Blue <i class="fa-solid fa-lines-leaning"></i>';
      modeValue.dataset.mode = 4;
    } else if (data.Config.control.mode === 5) {
      modeValue.innerHTML = 'GLow Red <i class="fa-solid fa-lines-leaning"></i>';
      modeValue.dataset.mode = 5;
    } else if (data.Config.control.mode === 6) {
      modeValue.innerHTML = 'Rainbow Wavy <i class="fa-solid fa-rainbow"></i>';
      modeValue.dataset.mode = 6;
    } else if (data.Config.control.mode === 7) {
      modeValue.innerHTML = 'Rainbow Fade <i class="fa-solid fa-rainbow"></i>';
      modeValue.dataset.mode = 7;
    }


    // ------------------------- Airator Control and Status -----------------------------
    airatorSwitch.checked = data.Config.control.airator.trigger;
    document.getElementById('airatorStatus').style.color = data.Config.control.airator.trigger ? '#1AD11F' : '#C42B05';

    $('#loader').fadeOut('slow');
  })
 

  changeMode.addEventListener('click', () => {
    const mode = modeValue.dataset.mode;
    const modeNumber = Number(mode) === 7 ? 1 : Number(mode) + 1;
    update(databaseRef, { '/Config/control/mode': modeNumber });
  })

  airatorSwitch.addEventListener('click', () => {
    // console.log(airatorSwitch.checked)
    update(databaseRef, { '/Config/control/airator/trigger': airatorSwitch.checked })
  })

  ledSwitch.addEventListener('click', () => {
    update(databaseRef, { '/Config/control/mode': ledSwitch.checked ? 1 : 0 })
  })
})